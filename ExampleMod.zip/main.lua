local mod = RegisterMod("My Custom Mod", 1)

if TCainRework then
    TCainRework:loadRegistry(include("loadorder"))
else
    print("This mod is meant to be used with Tainted Cain Rework! Please be sure to install it.")
end