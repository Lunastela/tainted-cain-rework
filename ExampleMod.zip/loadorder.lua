--[[
	This is your mod's load order. You may provide multiple load order to the registry, 
	just be sure to load them with the ``loadRegistry`` command. In here, you may add
	custom items to your mod's registry, so long as they are provided in "./data".
--]]
return {
	-- This is your mod's namespace. It is used to internally identify which mod the items came from.
	-- It can be anything, so long as the folder names are consistent with it.
	Namespace = "mycustommod",  
	-- This is your mod's custom DISPLAY name. This will show up whenever a discernable mod name is needed. 
	Name = "My Custom Mod",
	--[[
		This is the mod's item load order list. Item names are separated by newlines.
		Item data files may be located in "./data/[your namespace]/". It is here where you should add your items, as well as their data. 
		Once they are added, they must be added to the item load order list below, as there is no way to automatically detect lua files.
	--]]
	Items = [[
		buckettwo
		blue_wood
		crafting_table_2
	]]
}