return {
    ["shapeless_f97e973ef2ae2ba7b3e3713832927604afe3cae7"] = {
        {
            RecipeName = "johnsnailrecipes:anarchist_cookbook",
            Category = "collectible",
            ConditionTable = {"#book", "tcainrework:giga_bomb", "tcainrework:battery", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Anarchist Cookbook"
            },
            DisplayRecipe = true
        },
    },
    ["shapeless_aab12288cac8fd7738ff727162096cc65fc80bcd"] = {
        {
            RecipeName = "johnsnailrecipes:a_snack",
            Category = "collectible",
            ConditionTable = {"Yum Heart", "tcainrework:soul_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "A Snack"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:box_of_spiders",
            Category = "collectible",
            ConditionTable = {"minecraft:chest", "tcainrework:pill{\"pill_effect\":34}", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Box of Spiders"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:box_of_spiders_alt",
            Category = "collectible",
            ConditionTable = {"minecraft:chest", "tcainrework:pill{\"pill_effect\":35}", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Box of Spiders"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:we_need_to_go_deeper_alt",
            Category = "collectible",
            ConditionTable = {"tcainrework:rune{\"card_type\":34,\"custom_gfx\":\"gfx/items/cards/left_rune.png\"}", "minecraft:iron_shovel", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "We Need To Go Deeper!"
            },
            DisplayRecipe = false
        },
    },
    ["47b9f7adfdb636f43c05c63bbbd32a933e962f4a"] = {
        {
            RecipeName = "johnsnailrecipes:big_chubby",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "Little Chubby", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Big Chubby"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:bobs_curse",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:rotten_heart", "tcainrework:bomb", "tcainrework:rotten_heart", "tcainrework:bomb", "tcainrework:golden_bomb", "tcainrework:bomb", "tcainrework:rotten_heart", "tcainrework:bomb", "tcainrework:rotten_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Bob's Curse"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:champion_belt",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:heart", "tcainrework:heart", "tcainrework:heart", "minecraft:leather", "minecraft:leather", "minecraft:leather", "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Champion Belt"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:consolation_prize",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"#tcainrework:coin", "minecraft:oak_planks", "#tcainrework:bomb", "#tcainrework:heart", "minecraft:oak_planks", "#tcainrework:key", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Consolation Prize"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:fast_bombs",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:golden_bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Fast Bombs"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:little_baggy",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"minecraft:paper", "minecraft:paper", "minecraft:paper", "tcainrework:pill", "tcainrework:pill", "tcainrework:pill", "minecraft:paper", "minecraft:paper", "minecraft:paper", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Little Baggy"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:mr_mega",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:key", "tcainrework:bomb", "tcainrework:key", "tcainrework:bomb", "tcainrework:golden_bomb", "tcainrework:bomb", "tcainrework:key", "tcainrework:bomb", "tcainrework:key", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Mr. Mega"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:mystery_sack",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"#tcainrework:pickup", "minecraft:leather", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", "#tcainrework:pickup", "minecraft:leather", "#tcainrework:pickup", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Mystery Sack"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:the_pact",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:heart", "tcainrework:black_heart", "tcainrework:heart", "tcainrework:black_heart", "minecraft:paper", "tcainrework:black_heart", "tcainrework:heart", "tcainrework:black_heart", "tcainrework:heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "The Pact"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:wooden_doll",
            Category = "misc",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"minecraft:stick", "minecraft:oak_planks", "minecraft:stick", "minecraft:oak_planks", "#tcainrework:soul_heart", "minecraft:oak_planks", "minecraft:stick", "minecraft:oak_planks", "minecraft:stick", },
            Results = {
                Type = "tcainrework:wooden_doll",
                Count = 1
            },
            DisplayRecipe = true
        },
    },
    ["9830dfd9dbb24029b85cbe478591e547f65d1524"] = {
        {
            RecipeName = "johnsnailrecipes:black_powder",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "minecraft:leather", nil, "tcainrework:bomb", "#tcainrework:soul_heart", "tcainrework:bomb", nil, "minecraft:leather", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Black Powder"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:blood_oath",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "Iron Bar", nil, "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", nil, "tcainrework:heart", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Blood Oath"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:crack_jacks",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "#tcainrework:card", nil, "tcainrework:nickel", "Yum Heart", "tcainrework:nickel", nil, "#tcainrework:card", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Crack Jacks"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:playdough_cookie",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "#tcainrework:heart", nil, "#tcainrework:coin", "Fortune Cookie", "#tcainrework:key", nil, "#tcainrework:bomb", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Playdough Cookie"
            },
            DisplayRecipe = true
        },
    },
    ["shapeless_085fbabd884e6a20267d051dfd7bf5c6c12ac53a"] = {
        {
            RecipeName = "johnsnailrecipes:blood_bombs",
            Category = "collectible",
            ConditionTable = {"Blood Bag", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Blood Bombs"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:forever_alone",
            Category = "collectible",
            ConditionTable = {"The Poop", "tcainrework:rotten_heart", "tcainrework:rotten_heart", "tcainrework:soul_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Forever alone"
            },
            DisplayRecipe = true
        },
    },
    ["85f1ae3dcaf3a6c5984fbf8db91065c0489ade1a"] = {
        {
            RecipeName = "johnsnailrecipes:bomb_bag",
            Category = "collectible",
            RecipeSize = Vector(1, 3),
            ConditionTable = {"minecraft:leather", "tcainrework:giga_bomb", "minecraft:leather", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Bomb Bag"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:sack_of_pennies",
            Category = "collectible",
            RecipeSize = Vector(1, 3),
            ConditionTable = {"minecraft:leather", "A Quarter", "minecraft:leather", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Sack of Pennies"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:sulfur",
            Category = "collectible",
            RecipeSize = Vector(1, 3),
            ConditionTable = {"tcainrework:battery", "The Mark", "tcainrework:black_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Sulfur"
            },
            DisplayRecipe = true
        },
    },
    ["shapeless_cc630251aba90c8217236a47f7db67cf5dae30d4"] = {
        {
            RecipeName = "johnsnailrecipes:bomb_from_giga_bomb",
            Category = "misc",
            ConditionTable = {"tcainrework:giga_bomb", },
            Results = {
                Type = "tcainrework:bomb",
                Count = 9
            },
            DisplayRecipe = true
        },
    },
    ["2d823eb11031f127fe012f4690bf9ba131a71c84"] = {
        {
            RecipeName = "johnsnailrecipes:book_of_sin",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"#tcainrework:coin", nil, "#tcainrework:bomb", nil, "#book", nil, "#tcainrework:key", nil, "tcainrework:black_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "The Book of Sin"
            },
            DisplayRecipe = true
        },
    },
    ["shapeless_0453694150026183d94e13c2b2c72ad075c83a5c"] = {
        {
            RecipeName = "johnsnailrecipes:butt_bombs",
            Category = "collectible",
            ConditionTable = {"tcainrework:golden_bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", "tcainrework:bomb", "The Poop", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Butt Bombs"
            },
            DisplayRecipe = true
        },
    },
    ["2c5c63c65ce617382b5cc58b59571a3c83e0549c"] = {
        {
            RecipeName = "johnsnailrecipes:ceremonial_robes",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "tcainrework:black_heart", nil, "tcainrework:black_heart", nil, "tcainrework:black_heart", "tcainrework:black_heart", "tcainrework:black_heart", "tcainrework:black_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Ceremonial Robes"
            },
            DisplayRecipe = true
        },
    },
    ["69c2162ab075f3bbf3f3989d6023c82e5f36d895"] = {
        {
            RecipeName = "johnsnailrecipes:latch_key",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"#tcainrework:key", "#tcainrework:key", "#tcainrework:key", "#tcainrework:key", nil, "#tcainrework:key", "#tcainrework:key", "tcainrework:soul_heart", "#tcainrework:key", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Latch Key"
            },
            DisplayRecipe = true
        },
    },
    ["bf0ce597399da0189aa7cbfbd8e1dd99f4a7e7d3"] = {
        {
            RecipeName = "johnsnailrecipes:less_than_three_alt",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:heart", "tcainrework:bone_heart", "tcainrework:heart", nil, "Yum Heart", nil, nil, "tcainrework:heart", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "<3"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:screw",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"#tcainrework:pickup", "#tcainrework:key", "#tcainrework:pickup", nil, "#tcainrework:key", nil, nil, "#tcainrework:key", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Screw"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:we_need_to_go_deeper",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"minecraft:stick", "tcainrework:rune{\"card_type\":34,\"custom_gfx\":\"gfx/items/cards/left_rune.png\"}", "minecraft:stick", nil, "minecraft:stick", nil, nil, "Iron Bar", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "We Need To Go Deeper!"
            },
            DisplayRecipe = true
        },
    },
    ["f52f60dac6d005ff67d31a07c8aec14f8b831593"] = {
        {
            RecipeName = "johnsnailrecipes:lokis_horns",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "tcainrework:bomb", nil, "tcainrework:black_heart", nil, "tcainrework:black_heart", nil, "tcainrework:bomb", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Loki's Horns"
            },
            DisplayRecipe = true
        },
    },
    ["09d9aa953db5fe50691e346e92c07b7a04b92be5"] = {
        {
            RecipeName = "johnsnailrecipes:pentagram",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {"tcainrework:black_heart", nil, "tcainrework:black_heart", nil, nil, nil, nil, "tcainrework:black_heart", nil, },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Pentagram"
            },
            DisplayRecipe = true
        },
    },
    ["shapeless_83d0a6c92856cdf4681bcc6ff9cbfd7839630cc5"] = {
        {
            RecipeName = "johnsnailrecipes:rubber_cement",
            Category = "collectible",
            ConditionTable = {"Eye Drops", "Lil Gurdy", "The Jar", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Rubber Cement"
            },
            DisplayRecipe = true
        },
    },
    ["d6202ba69ed604b9d9ce657c38dc924b7bfb4897"] = {
        {
            RecipeName = "johnsnailrecipes:sad_bombs",
            Category = "collectible",
            RecipeSize = Vector(2, 3),
            ConditionTable = {"tcainrework:bomb", "tcainrework:bomb", "tcainrework:golden_bomb", "Epiphora", "tcainrework:bomb", "tcainrework:bomb", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Sad Bombs"
            },
            DisplayRecipe = true
        },
    },
    ["17b43ca59cc2279bbd8fb58974a49350d8c35ad3"] = {
        {
            RecipeName = "johnsnailrecipes:safety_pin",
            Category = "collectible",
            RecipeSize = Vector(2, 2),
            ConditionTable = {"#tcainrework:soul_heart", "tcainrework:key", "tcainrework:key", "#tcainrework:soul_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Safety Pin"
            },
            DisplayRecipe = true
        },
    },
    ["87d12c5a4ede0dc54b2552cd180f7c3f49266148"] = {
        {
            RecipeName = "johnsnailrecipes:the_jar",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "minecraft:oak_planks", nil, "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", "tcainrework:heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "The Jar"
            },
            DisplayRecipe = true
        },
        {
            RecipeName = "johnsnailrecipes:the_wiz",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "minecraft:paper", nil, "minecraft:paper", "tcainrework:pill{\"pill_effect\":27}", "minecraft:paper", "minecraft:paper", "minecraft:paper", "minecraft:paper", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "The Wiz"
            },
            DisplayRecipe = true
        },
    },
    ["7b89611d1a255f5f2db57b9417744e406bedd1c3"] = {
        {
            RecipeName = "johnsnailrecipes:the_mark",
            Category = "collectible",
            RecipeSize = Vector(3, 3),
            ConditionTable = {nil, "tcainrework:black_heart", nil, nil, nil, nil, "tcainrework:black_heart", nil, "tcainrework:black_heart", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "The Mark"
            },
            DisplayRecipe = true
        },
    },
    ["8f679172b3f6fad7d638f452a8c4575bb41469e9"] = {
        {
            RecipeName = "johnsnailrecipes:wirecoat_hanger",
            Category = "collectible",
            RecipeSize = Vector(3, 2),
            ConditionTable = {"#tcainrework:pickup", "#tcainrework:key", "#tcainrework:pickup", "#tcainrework:key", "#tcainrework:key", "#tcainrework:key", },
            Results = {
                Type = "tcainrework:collectible",
                Count = 1,
                Collectible = "Wire Coat Hanger"
            },
            DisplayRecipe = true
        },
    },
}