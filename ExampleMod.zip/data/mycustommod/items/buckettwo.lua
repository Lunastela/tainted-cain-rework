return {
    Properties = {
        -- Items can be given a display name and graphics file.
        DisplayName = "Bucket TWO!!!",
        GFX = "gfx/mycustommod/items/bucket.png",
        -- The default RenderModel is used to render an item.
        RenderModel = InventoryItemRenderType.Default,
        -- This example's stack size is set to 1.
        StackSize = 1,
        -- This item has an item tag. It can be referenced by it in recipes.
        ItemTags = {
            -- Item tags compiled if any item contains them.
            -- They do not need to be explicitly defined.
            "#mycustommod:bucket_two_tag"
        },
        -- Rarities include Common, Uncommon, Rare, Epic and Legendary.
        Rarity = InventoryItemRarity.LEGENDARY,
        -- We set the item to enchanted to check if it renders properly.
        Enchanted = true
    },
    -- To create an interaction with the Bag of Crafting, provide an ObtainedFrom table below the Properties table of an item.
    ObtainedFrom = {
        -- "5", -- If uncommented, the item will be received from picking up any pickup (Type 5) at all with the Bag of Crafting.
        -- "5.300.80", -- If uncommented, the item will be received when picking up a wild card (Type 5.300.80) with the Bag of Crafting.
        --[[ -- If uncommented, the item will be received from any card (Type 5.300), and will provide 3 of itself.
        {
            EntityID = "5.300",
            Amount = 3,
        }
        --]]
        --[[ An example of a conditional return. 
        {
            EntityID = "5.300", -- This condition will run for any entity in the 5.300 category.
            Amount = 1, -- This condition will return 1 of the item provided.
            Condition = function(entity, player)
                -- This table can return any amount of Component information about the item. 
                -- See pills and cards for more information.
                return {} 
                -- Returning false will abort the operation, and stop the item from going into the bag.
                -- return false
            end
        }
        --]]
    }
}