return {
    Properties = {
        DisplayName = "Crafting Table...2???",
        GFX = "gfx/mycustommod/blocks/crafting_table_2.png",
        -- RenderModel Crafting Table can be used for blocks with multiple faces.
        RenderModel = InventoryItemRenderType.CraftingTable,
        -- This example's stack size is set to 16.
        StackSize = 16,
        -- Rarities include Common, Uncommon, Rare, Epic and Legendary.
        Rarity = InventoryItemRarity.RARE,
        -- Blocks may also be enchanted per face.
        Enchanted = true
    }
}