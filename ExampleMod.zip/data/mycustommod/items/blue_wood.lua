return {
    Properties = {
        DisplayName = "blue wood",
        GFX = "gfx/mycustommod/blocks/blue_wood.png",
        RenderModel = InventoryItemRenderType.SimpleBlock,
        -- This example's stack size is set to 64.
        StackSize = 64,
        Rarity = InventoryItemRarity.COMMON,
        -- This item is not enchanted.
        Enchanted = false
    }
}